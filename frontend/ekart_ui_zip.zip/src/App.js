import React from 'react';
//import logo from './logo.svg';
import './App.css';
//import data from './data'
import {BrowserRouter,Route,Link} from 'react-router-dom'
import HomeScreen from './Screens/HomeScreen';
import ProductScreen from './Screens/ProductScreen'
import CartScreen from './Screens/CartScreen';
import SigninScreen from './Screens/signinScreen';
import { useSelector } from 'react-redux';
import registerScreen from './Screens/registerScreen';
import ProductsScreen from './Screens/ProductsScreen';
import ShippingScreen from './Screens/shippingScreen';
import PaymentScreen from './Screens/paymentScreen';
import PlaceOrderScreen from './Screens/placeOrderScreen';
import FileUpload from './Screens/uploadPhoto';
import Axios from 'axios';
function App() {
  const userSignin = useSelector(state=>state.userSignin);
  const {userInfo} = userSignin;
  const openMenu=()=>{
    document.querySelector(".sidebar").classList.add("open")
  }
  const closeMenu=()=>{
    document.querySelector(".sidebar").classList.remove("open")
  }
  const searchObj = (obj) =>{
    console.log(obj)
    Axios.get("http://localhost:5000/api/products/selectP/"+obj)
        .then((response) => {
            console.log(response)
            sessionStorage.setItem('sData',JSON.stringify(response.data))
            console.log(sessionStorage.getItem('sData'))
            window.location.reload(true)
        }).catch((error) => {
            if (error.response) {
                console.log(error.response)
            } else {
                // 
                console.log(error)
            }

        })
  }
  return (
    <BrowserRouter>
      <div className="grid-container">
        <header className="header">
            <div className="brand">
                <button onClick={openMenu}>
                    &#9776;
                </button>
                <Link to="/">amazona</Link>
                
            </div>
            
            <div className="header-links">
                <a href="/upload">uploadPic</a>
                <a href="/cart">Cart</a>
                <a href="/products">Add Products</a>
                {
                  userInfo? <Link to="/profile">{userInfo.name}</Link>:
                  <Link to="/signin">Signin</Link>
                }
            </div>
        </header>
        <aside className="sidebar">
            <h3>Shopping Categories</h3>
            <button className="sidebar-close-button" onClick={closeMenu}>x</button>
            <ul>
                <li>
                    <a onClick={()=>{sessionStorage.clear();
                    window.location.reload(true)}} >all</a>
                </li>
                <li>
                    <a onClick={()=>searchObj("pant")} >Pants</a>
                </li>
                <li>
                    <a  onClick={()=>searchObj("shirt")}>shirt</a>
                </li>
                <li>
                    <a  onClick={()=>searchObj("saree")}>saree</a>
                </li>
                <li>
                    <a  onClick={()=>searchObj("top")}>top</a>
                </li>
            </ul>
        </aside>
        <main className="main">
            <div className="content">
              <Route path="/upload" component={FileUpload}/>
              <Route path="/products"component={ProductsScreen}/>
              <Route path="/shipping"component={ShippingScreen}/>
              <Route path="/payment"component={PaymentScreen}/>
              <Route path="/placeorder"component={PlaceOrderScreen}/>
              <Route path="/signin"  component={SigninScreen}/>
              <Route path="/register"  component={registerScreen}/>
              <Route path="/product/:id" component={ProductScreen}/>
              <Route path="/cart/:id?" component={CartScreen}/>
              <Route path="/" exact={true} component={HomeScreen}/>
                
            </div>
            
        </main>
        <footer className="footer">
            All rights reserved
        </footer>
    </div>
    </BrowserRouter>
  )
}

export default App;
