import React,{ useEffect} from 'react';
import { useSelector, useDispatch} from 'react-redux';
//import data from '../data'
import {Link} from 'react-router-dom'
//import axios from 'axios'
import { listProducts } from '../actions/productActions';
function HomeScreen(props) {
    //const [products,setProduct]=useState([]);
    const productList=useSelector((state)=> (state.productList));
    const {products, loading, error} = productList;
    const dispatch = useDispatch();
    const selProduct = sessionStorage.getItem('sData') 
    var selProducts = JSON.parse(selProduct)
    
    
    
    useEffect(()=>{
      // const fetchData=async ()=>{
      //   const {data}=await axios.get("http://localhost:5000/api/products");
      //   console.log(data)
      //   setProducts(data)
      // }
      //fetchData();
      dispatch(listProducts())
      return ()=>{
        //
      };
      },[])

    return loading ? <div>loading..</div>:
    error ? <div>{error}</div>:
    selProducts ? 
    <ul className="products">
      {
        selProducts.map(product => 
          <li key={product._id}>
            <div className="product">
              <Link to={'/product/'+product._id}>
                <img className="product-image" src={product.image} alt="product1"></img>
              </Link>
                
        <div className="product-name">
            <Link to={'/product/'+product._id}>{product.name}</Link></div>
                <div className="product-brand">{product.brand}</div>
                <div className="product-price">${product.price}</div>
                <div className="product-rating">{product.rating} stars({product.numReview} reviews)</div>
            </div>
        </li>)
      }  
    </ul>:
    <ul className="products">
    {
      products.map(product => 
        <li key={product._id}>
          <div className="product">
            <Link to={'/product/'+product._id}>
              <img className="product-image" src={product.image} alt="product1"></img>
            </Link>
              
      <div className="product-name">
          <Link to={'/product/'+product._id}>{product.name}</Link></div>
              <div className="product-brand">{product.brand}</div>
              <div className="product-price">${product.price}</div>
              <div className="product-rating">{product.rating} stars({product.numReview} reviews)</div>
          </div>
      </li>)
    }  
  </ul>

}

export default HomeScreen;