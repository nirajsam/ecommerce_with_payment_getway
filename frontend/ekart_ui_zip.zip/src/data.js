export default{
    products:[
    {
        _id:'1',
        name:'Slim Shirt',
        category:'Shirts',
        image:'/images/d1.jpeg',
        price:600,
        brand:'Nike',
        rating:4.5,
        numReview:10
    },
    {
        _id:'2',
        name:'Fit Shirt',
        category:'Shirts',
        image:'/images/d1.jpeg',
        price:800,
        brand:'Nike',
        rating:4.5,
        numReview:11
    },
    {
        _id:'3',
        name:'Check Shirt',
        category:'Shirts',
        image:'/images/d1.jpeg',
        price:600,
        brand:'hrx',
        rating:5.0,
        numReview:19
    },
    {
        _id:'4',
        name:'Best Pants',
        category:'Pants',
        image:'/images/d1.jpeg',
        price:500,
        brand:'peter',
        rating:3.5,
        numReview:6
    },
    {
        _id:'5',
        name:'Best Pants',
        category:'Pants',
        image:'/images/d1.jpeg',
        price:500,
        brand:'peter',
        rating:3.5,
        numReview:6
    },
    {
        _id:'6',
        name:'Best Pants',
        category:'Pants',
        image:'/images/d1.jpeg',
        price:500,
        brand:'peter',
        rating:3.5,
        numReview:6
    }
]
}